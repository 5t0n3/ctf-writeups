#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>
#include <sys/mman.h>

#define NUM_ROWS 30
#define NUM_COLS 26
#define MAX_LEN 2048

char shellcode[2048];

// Thanks ChatGPT
static const char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

char *base64_decode(const char *encoded_data, int *decoded_length) {
    int i, j, padding = 0, data_length = strlen(encoded_data);
    char *decoded_data;

    if (data_length % 4 != 0) {
        padding = 4 - (data_length % 4);
    }

    *decoded_length = data_length / 4 * 3 - padding;

    decoded_data = (char*)malloc(*decoded_length);

    for (i = 0, j = 0; i < data_length; i += 4, j += 3) {
        int b[4] = {0};

        b[0] = strchr(base64_chars, encoded_data[i]) - base64_chars;
        b[1] = strchr(base64_chars, encoded_data[i + 1]) - base64_chars;
        b[2] = strchr(base64_chars, encoded_data[i + 2]) - base64_chars;
        b[3] = strchr(base64_chars, encoded_data[i + 3]) - base64_chars;

        decoded_data[j] = (char)((b[0] << 2) | (b[1] >> 4));
        if (b[2] < 64) {
            decoded_data[j + 1] = (char)((b[1] << 4) | (b[2] >> 2));
            if (b[3] < 64) {
                decoded_data[j + 2] = (char)((b[2] << 6) | b[3]);
            }
        }
    }

    return decoded_data;
}

int main(int argc, char* argv[]) {
    char *filename;
    int row;
    int col;
    bool ex;
    char *argument;
    char *contents[NUM_ROWS][NUM_COLS] = {};

    if (argc != 5) {
        printf(
            "dead: CLI utility for the Dangerously Extensible Ancient Database\n"
            "\n"
            "Usage: ./dead <filename> <operation> [cell] [argument]\n"
            "  filename      Name of the file update\n"
            "  operation     UPDATE or UPDATE_EX\n"
            "  cell          If operation is UPDATE or UPDATE_EX, specifies the row,column of the\n"
            "                cell on which to perform the update operation\n"
            "  argument      If operation is UPDATE, specifies the value to update the cell with\n"
            "                If operation is UPDATE_EX, specifies the base64 encoded shellcode used\n"
            "                to update the cell. The shellcode starts at address "
        );
        printf("%p\n", shellcode);
        return 1;
    }

    filename = argv[1];
    ex = strcmp("UPDATE_EX", argv[2]) == 0;
    sscanf(argv[3], "%d", &row);
    sscanf(strchr(argv[3], ',') + 1, "%d", &col);
    argument = argv[4];

    // Open file
    FILE *f;
    if ((f = fopen(filename, "r"))) {
        // Parse
        char *line = NULL;
        size_t n = 0;
        for (int i = 0; i < NUM_ROWS; i++) {
            getline(&line, &n, f);
            int len = strlen(line);
            if (line[len - 1] == '\n') {
                line[len - 1] = '\0';
            }
            char *val = line;
            char *comma;
            int val_len;
            for (int j = 0; j < NUM_COLS; j++) {
                comma = strchr(val, ',');
                if (comma) {
                    val_len = comma - val;
                }
                else {
                    val_len = len - (val - line);
                }
                if (val_len != 0) {
                    contents[i][j] = malloc(val_len + 1);
                    memcpy(contents[i][j], val, val_len);
                    contents[i][j][val_len] = '\0';
                }
                val = comma + 1;
            }
        }
        free(line);
        fclose(f);
    }


    // Update value
    if (contents[row][col]) {
        free(contents[row][col]);
        contents[row][col] = NULL;
    }
    if (ex) {
        int shellcode_length;
		char *decoded = base64_decode(argument, &shellcode_length);
        shellcode_length = shellcode_length < MAX_LEN ? shellcode_length : MAX_LEN;
        memcpy(shellcode, decoded, shellcode_length);
        free(decoded);

        // Run shellcode to determine the value with which to update the cell
        mprotect(shellcode - ((long int)shellcode % 4096), 4096, PROT_READ | PROT_WRITE | PROT_EXEC);
        char *(*shellcode_func)() = (char *(*)())shellcode;
        char *result = shellcode_func();
        
        // Copy the result of running the shellcode into the cell
        contents[row][col] = malloc(strlen(argument) + 1);
        memcpy(contents[row][col], result, strlen(result) + 1);
    }
    else {
        contents[row][col] = malloc(strlen(argument) + 1);
        memcpy(contents[row][col], argument, strlen(argument) + 1);
    }

    // Write the new file
    f = fopen(filename, "w");
    if (!f) {
        perror("Failed to open file for writing");
        return 1;
    }
    for (int i = 0; i < NUM_ROWS; i++) {
        for (int j = 0; j < NUM_COLS; j++) {
            if (contents[i][j]) {
                fprintf(f, "%s", contents[i][j]);
                // Free memory
                free(contents[i][j]);
            }
            if (j < NUM_COLS - 1) {
                fprintf(f, ",");
            }
        }
        if (i < NUM_ROWS - 1) {
            fprintf(f, "\n");
        }
    }
    fclose(f);

    return 0;
}
