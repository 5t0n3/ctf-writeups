#!/usr/bin/env python3

from flask import Flask, request, render_template, send_from_directory, redirect
import os
from pathlib import Path
import uuid
import subprocess

app = Flask(__name__, static_url_path='/static', static_folder='static')

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/new')
def new_sheet():
    name = uuid.uuid4()
    command = ("./dead", f"{name}.dead", f"UPDATE", f"0,0", '')
    subprocess.run(command)
    return redirect(f'/sheet/{name}')

@app.route('/sheet/<string:name>', methods=['GET'])
def get_sheet(name):
    sheet_path = Path.cwd().joinpath(f"{name}.dead")
    if sheet_path.exists():
        with open(sheet_path, 'rb') as f:
            contents = []
            for line in f:
                contents += [[x.decode(encoding='utf-8', errors='replace') for x in line.strip().split(b',')]]
        return render_template('sheet.html', contents=contents, uuid=name)
    else:
        return 'Sheet not found', 404

@app.route('/update', methods=['POST'])
def update():
    name = request.json['uuid']
    sheet_path = Path.cwd().joinpath(f"{name}.dead")
    if sheet_path.exists():
        row = request.json['row']
        col = request.json['col']
        ex = request.json['ex']
        value = request.json['value']
        command = ("./dead", sheet_path, f"UPDATE{'_EX' if ex else ''}", f"{row},{col}", value)
        subprocess.run(command)
        return "ok"
    else:
        return 'Sheet not found', 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=1353, debug=True)

