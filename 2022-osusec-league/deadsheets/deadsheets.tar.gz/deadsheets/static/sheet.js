var current_row = 0;
var current_col = 0;
var current_value = "";
var updated = false;
var current_uuid = "";
function updateCell(uuid, row, col, value) {
  current_row = row;
  current_col = col;
  current_value = value;
  current_uuid = uuid;
  updated = true;
}

document.body.addEventListener('click', () => {
  if (!updated) {
    return;
  }
  let row = current_row;
  let col = current_col;
  let value = current_value;
  let uuid = current_uuid;
  ex = document.getElementById("edit_mode").value == "extensible";
  // Send POST request to /update with row, col, and value parameters
  fetch('/update', {
    method: 'POST',
    body: JSON.stringify({uuid: uuid, row: row, col: col, ex: ex, value: value}),
    headers: {'Content-Type': 'application/json'}
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      console.log(data);
      location.reload();
    })
    .catch(error => {
      console.error('There was a problem with the fetch operation:', error);
    });
}, true);

