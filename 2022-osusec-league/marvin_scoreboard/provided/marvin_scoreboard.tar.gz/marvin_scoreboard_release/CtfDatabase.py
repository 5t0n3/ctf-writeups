import mysql.connector

class CtfDatabase:
    def __init__(self, config, log):
        self.log = log
        self.config = config

    def begin_sql_connection(self):
        connection = mysql.connector.connect(**(self.config), buffered=True)
        connection.autocommit = True 
        return connection
    
    def end_sql_connection(self, connection):
        connection.close()

    def sql_fetchone(self, connection, sql, val=None):
        connection.ping(reconnect=True, attempts=2, delay=2)
        self.log.log("SQL: " + sql)
        cursor = connection.cursor()
        if val:
            self.log.log("VAL: " + repr(val))
            cursor.execute(sql, val)
        else:
            cursor.execute(sql)
        ret = cursor.fetchone()
        cursor.close()
        return ret

    def sql_fetchall(self, connection, sql, val=None):
        connection.ping(reconnect=True, attempts=2, delay=2)
        self.log.log("SQL: " + sql)
        cursor = connection.cursor()
        if val:
            self.log.log("VAL: " + repr(val))
            cursor.execute(sql, val)
        else:
            cursor.execute(sql)
        ret = cursor.fetchall()
        cursor.close()
        return ret

    def sql_commit(self, connection, sql, val=None):
        connection.ping(reconnect=True, attempts=2, delay=2)
        self.log.log("SQL: " + sql)
        cursor = connection.cursor()
        if val:
            self.log.log("VAL: " + repr(val))
            cursor.execute(sql, val)
        else:
            cursor.execute(sql)
        connection.commit()
        ret = cursor.lastrowid
        cursor.close()
        return ret
