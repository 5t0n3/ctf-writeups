import uuid
import markdown
from flask import Flask, render_template, send_from_directory, request, make_response, redirect, url_for
from Logger import Logger
from CtfDatabase import CtfDatabase
from Scorekeeper import Scorekeeper
import config
import plotly.graph_objects as go
import json
import plotly
from datetime import datetime, timedelta
from plotly.graph_objs import *
from collections import defaultdict

app = Flask(__name__)
log = Logger()
db = CtfDatabase(config.DB_CONFIG, log)
sk = Scorekeeper(db, log)

if config.GRAPH_PLAYERS > 240:
    print("config.GRAPH_PLAYERS must be less than or equal to 10")
    exit(-1)


@app.route("/")
def index():
    limit=1000
    try:
        limit = int(request.args.get('limit'))
    except:
        pass
    # Get the scores
    scores = sk.calculate_scores()

    # Refine data to be just top 10 players, extract the data about
    # those players to graph_data
    graph_data = scores[:config.GRAPH_PLAYERS]

    # Set backgtound color to clear
    # https://stackoverflow.com/questions/29968152/setting-background-color-to-transparent-in-plotly-plots
    layout = Layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")

    # Create a figure, using the clear background layout.
    # Update the shift for the 'B' value on each new trace, to shift the
    # color for each player.
    fig = go.Figure(layout=layout)
    shift = 0
    for score in graph_data:
        fig.add_trace(
            go.Line(
                x= [score[2][0] - timedelta(days=1)] + score[2] + [datetime.now() + timedelta(hours=config.TIME_OFFSET_FROM_UTC)],
                y= [0] + score[3] + [score[3][-1]],
                name=score[1],
                line=dict(color="rgb(215, 63, " + str(int(9 + shift)) + ")", width=3),
                textfont_color="rgb(215, 63, " + str(int(9 + shift)) + ")",
            )
        )
        shift += int(240/config.GRAPH_PLAYERS)

    # Update graph to use orange text throughout
    fig.update_layout(
        font_color="rgb(215, 63, 9)", legend_title_font_color="rgb(215, 63, 9)"
    )

    # Convert the y axis information into ints because they are strings
    fig.update_layout(autotypenumbers='convert types')

    #fig.update_layout(yaxis=dict(autorange="reversed"))

    # Update each trace to use orange color in label
    # fig.for_each_trace(lambda t: t.update(textfont_color="rgb(215, 63, 9)"))

    # Generate JSON for graph
    graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

    limit_str = "none"
    if limit in [10, 50, 100]:
        limit_str = str(limit)

    return render_template(
        "scoreboard.html", scores=scores[:limit], graphJSON=graphJSON, limit=limit_str
    )

@app.route("/writeups")
def writeups():
    connection = db.begin_sql_connection()
    # query db for writeups
    db_res = db.sql_fetchall(connection, "SELECT nickname, name, text, release_time, num_weeks FROM writeups INNER JOIN users ON writeups.user_id=users.discord_id INNER JOIN challenges ON writeups.chal_id=challenges.chal_id WHERE approved=1")

    # split up writeups by challenge
    writeups = defaultdict(list)
    for w in db_res:
        # only add challenge if it is no longer accepting flag submissions for points
        if datetime.now() > ((w[3] + timedelta(hours=config.TIME_OFFSET_FROM_UTC)).replace(hour=18,minute=0,second=0,microsecond=0) + timedelta(days=(7 * w[4]), hours=-1*config.TIME_OFFSET_FROM_UTC)):
            writeups[w[1]].append([w[0], w[2]])

    to_render = [[w, writeups[w]] for w in writeups]

    db.end_sql_connection(connection)
    return render_template("writeups.html", writeups=to_render)

@app.route("/api/user/<username>")
def get_user(username):
    # Get the scores
    scores = sk.calculate_scores()

    connection = db.begin_sql_connection()
    # get user id and nickname from username
    user_id_q = db.sql_fetchall(connection, "SELECT id, nickname FROM members INNER JOIN users ON users.discord_id=members.id WHERE username LIKE %s", val=(f"%{username}%",))
    if len(user_id_q) != 1:
        # Invalid username
        db.end_sql_connection(connection)
        return {"error": "Invalid username"}, 200
    user_id = user_id_q[0][0]
    nickname = user_id_q[0][1]

    # for getting the number of group challenges solved
    group_solves = db.sql_fetchall(\
        connection, \
        "SELECT name " + \
        "FROM challenges " + \
        "INNER JOIN solves " + \
        "ON challenges.chal_id=solves.chal_id " + \
        "WHERE team_id IN (" + \
            "SELECT team_id FROM teams WHERE " + \
            " OR ".join([f"player_{i}=%s" for i in range(21)]) + \
        ") ", \
        val=tuple([user_id]*21)\
    )

    # for getting the number of solo challenges solved
    solo_solves = db.sql_fetchall(\
        connection, \
        "SELECT name, discord_id " + \
        "FROM solo_solves " + \
        "INNER JOIN challenges " + \
        "ON challenges.chal_id=solo_solves.chal_id " + \
        "WHERE discord_id=%s", \
        val=(user_id,)\
    )

    # get score and rank for this user from the score list
    score = 0
    rank = 0
    for s in scores:
        if str(s[-1]) == str(user_id):
            score = s[-2][-1]
            rank = s[0]
            break

    challenges_solved = [x[0] for x in group_solves + solo_solves]
    db.end_sql_connection(connection)
    return \
    {
        "nickname": nickname,
        "user_id": str(user_id),
        "rank": rank,
        "score": score,
        "total_players": len(scores),
        "challenges_solved": len(challenges_solved)
    }

@app.route("/api/scores/")
def get_scores():
    # Get the scores
    scores = sk.calculate_scores()

    return\
    {"scores": [
        {
            "rank": s[0],
            "user_id": str(s[4]),
            "nickname": s[1],
            "total_score": s[3][-1],
            "timestamps": s[2],
            "scores": s[3]
        } \
        for s in scores
    ]}

@app.route("/api/challenges/")
def get_challenges():
    connection = db.begin_sql_connection()
    challenges = db.sql_fetchall(\
        connection, \
        "SELECT chal_id, name, category, points, download, access, description " + \
        "FROM challenges " + \
        "WHERE release_time IS NOT NULL"
    )

    # query db for writeups
    db_res = db.sql_fetchall(\
        connection, \
        "SELECT nickname, writeups.chal_id, text, release_time, num_weeks, writeups.user_id " + \
        "FROM writeups " + \
        "INNER JOIN users " + \
        "ON writeups.user_id=users.discord_id " + \
        "INNER JOIN challenges " + \
        "ON writeups.chal_id=challenges.chal_id " + \
        "WHERE approved=1"\
    )

    # split up writeups by challenge
    writeups = defaultdict(list)
    for w in db_res:
        # only add challenge if it is no longer accepting flag submissions for points
        if datetime.now() > ((w[3] + timedelta(hours=config.TIME_OFFSET_FROM_UTC)).replace(hour=18,minute=0,second=0,microsecond=0) + timedelta(days=(7 * w[4]), hours=-1*config.TIME_OFFSET_FROM_UTC)):
            writeups[w[1]].append(
                {
                    "user_id": str(w[5]),
                    "nickname": w[0],
                    "link": w[2]
                }
            )

    # consolidate challenges and writeups
    chal_arr = []
    for c in challenges:
        chal_arr.append(
            {
                "name": c[1],
                "category": c[2],
                "points": c[3],
                "download": c[4],
                "access": c[5],
                "description": c[6],
                "writeups": writeups[c[0]]
            }
        )
    db.end_sql_connection(connection)
    return \
    {
        "challenges": chal_arr
    }

def save_token(token, username):
    # store the token, username, and expiration date in the database
    exp = datetime.utcnow() + timedelta(hours=24)
    db_con = db.begin_sql_connection()
    db.sql_commit(db_con, "UPDATE admin_users SET token=%s, exp=%s WHERE username=%s", val=(token, exp, username))
    db.end_sql_connection(db_con)

def get_username_from_token(token):
    # look up the token in the database
    # return the associated username if the token is valid and has not expired
    username = None
    db_con = db.begin_sql_connection()
    res = db.sql_fetchone(db_con, "SELECT username, exp FROM admin_users WHERE token=%s", val=(token,))
    if res:
        username, exp = res
        if exp < datetime.now():
            username = None
    db.end_sql_connection(db_con)
    return username

def check_auth(request):
    if 'token' in request.cookies:
        # look up the token in the database
        token = request.cookies['token']
        username = get_username_from_token(token)
        if username:
            return True
    return False

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # check the username and password against the database
        db_con = db.begin_sql_connection()
        res = db.sql_fetchone(db_con, "SELECT username, token, exp FROM admin_users WHERE username=%s AND password=%s", val=(username, password))
        db.end_sql_connection(db_con)
        if res:
            username, token, exp = res
            if exp and exp < datetime.now():
                # create a new secure token
                token = str(uuid.uuid4())
            # store the token in the database and update expiration
            save_token(token, username)
            # set the cookie to the token value
            response = make_response(redirect(url_for('approve_writeup')))
            response.set_cookie('token', token)
            return response
        else:
            # redirect to the login page with an error message
            return redirect(url_for('login'))
    else:
        # render the login template
        return render_template("login.html")

@app.route('/approve_writeup')
def approve_writeup():
    if check_auth(request):
        db_con = db.begin_sql_connection()
        writeups = db.sql_fetchall(db_con, "SELECT nickname, name, writeup_id FROM writeups INNER JOIN users ON discord_id=user_id INNER JOIN challenges ON challenges.chal_id=writeups.chal_id WHERE approved IS NULL ORDER BY writeup_id DESC")
        db.end_sql_connection(db_con)
        print(writeups)
        return render_template('approve_writeup.html', writeups=writeups)
    # the user is not authenticated
    return redirect(url_for('login'))

@app.route('/approve_writeup/<writeup_id>')
def approve_writeup_details(writeup_id):
    if check_auth(request):
        db_con = db.begin_sql_connection()
        writeup = db.sql_fetchone(db_con, "SELECT nickname, name, text FROM writeups INNER JOIN users ON discord_id=user_id INNER JOIN challenges on challenges.chal_id=writeups.chal_id WHERE writeup_id=%s", val=(writeup_id,))
        db.end_sql_connection(db_con)
        nickname, name, writeup_text = writeup
        # Check if the writeup contents are a link or markdown
        if writeup_text.startswith("http"):
            # If it's a link, generate html for an iframe preview
            writeup_html = f'<iframe src="{writeup_text}" width="100%" height="500"></iframe>'
        else:
            # If it's markdown, convert it to html
            print(repr(writeup_text))
            writeup_html = markdown.markdown(writeup_text, extensions=['fenced_code', 'codehilite', 'nl2br'])
        return render_template("approve_writeup_detail.html", username=nickname, challenge_name=name, writeup_html=writeup_html, writeup_id=writeup_id)
    # the user is not authenticated
    return redirect(url_for('login'))

@app.route('/approve_writeup_id/<writeup_id>')
def approve_writeup_id(writeup_id):
    if check_auth(request):
        return "not implemented yet"
    return redirect(url_for('login'))

@app.route('/deny_writeup_id/<writeup_id>')
def deny_writeup_id(writeup_id):
    if check_auth(request):
        return "not implemented yet"
    return redirect(url_for('login'))

@app.route('/flag')
def flag():
    if check_auth(request):
        return open('/flags/marvin_scoreboard_flag').read()
    return redirect(url_for('login'))

@app.route("/static/<path:path>")
def send_static(path):
    return send_from_directory("static", path)
