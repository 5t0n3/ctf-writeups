import datetime
from collections import defaultdict
import config

class Scorekeeper:
    def __init__(self, db, log):
        self.db = db
        self.log = log

    def calculate_decay(self, points, submission_time, release_time, num_weeks):
        # First hour: 100%
        if submission_time - release_time <= datetime.timedelta(hours=1):
            return points
        # After first hour: 50%
        return int(0.5 * points)

    def calculate_scores(self):
        connection = self.db.begin_sql_connection()
        solves = self.db.sql_fetchall(connection, "SELECT submission_time,name,points,release_time,num_weeks," + ",".join(["player_" + str(i) for i in range(21)]) + " FROM solves INNER JOIN teams ON solves.team_id=teams.team_id INNER JOIN challenges ON solves.chal_id=challenges.chal_id;")
        
        scores = defaultdict(list)

        # Add solo solves to scores
        solo_scores = self.db.sql_fetchall(
            connection, 
            """
            SELECT points, submission_time, release_time, num_weeks, discord_id
            FROM solo_solves
            INNER JOIN challenges
            ON challenges.chal_id = solo_solves.chal_id
            """
        )
        if solo_scores:
            for solo_score in solo_scores:
                 scores[solo_score[4]].append([solo_score[1], self.calculate_decay(solo_score[0], solo_score[1], solo_score[2], solo_score[3])])

        # Add writeups to scores
        writeups = self.db.sql_fetchall(
            connection,
            """
            SELECT approved_date, user_id
            FROM writeups
            INNER JOIN challenges
                ON challenges.chal_id = writeups.chal_id
            WHERE approved=1
                AND release_time >= DATE_SUB(NOW(), INTERVAL 15 DAY)
            """
        )
        if writeups:
            for writeup in writeups:
                scores[writeup[1]].append([writeup[0], 100])

        # Add team solves to scores
        for solve in solves:
            # figure out how many points this is worth and which players to update
            chal_name = solve[1]
            submitted_time = solve[0]
            chal_points = self.calculate_decay(solve[2], solve[0], solve[3], solve[4])

            # loop through all players on this team
            i = 5
            while i < 26 and solve[i] != None:
                player_id = solve[i]
                player_chal_score = chal_points
                
                # add to player scores
                scores[player_id].append([submitted_time, player_chal_score])
                i += 1

        nicknames = {id:name for (id, name) in self.db.sql_fetchall(connection, "SELECT discord_id,nickname FROM users;")}

        for player in scores:
            # sort solve list based on submission time
            scores[player].sort(key=lambda score:score[0])
            # make scores cumulative
            prev_score = 0
            for i in range(len(scores[player])):
                scores[player][i][1] += prev_score
                prev_score = scores[player][i][1]
        
        # make a list of scores for the scoreboard
        sorted_players = [x for x in sorted(scores.keys(), key=lambda x:scores[x][-1][1], reverse=True)]
        rankings = []

        for i in range(len(sorted_players)):
            rank = i + 1
            id = sorted_players[i]
            name = nicknames[id]
            # fix time zone here because this seems like a good place to fix it if you're looking for time zone problems look here this is the timezone fixing code take a look if you need to fix time zone problems this is where to do it
            times = [(t[0] + datetime.timedelta(hours=config.TIME_OFFSET_FROM_UTC)) for t in scores[id]]
            point_totals = [t[1] for t in scores[id]]

            rankings.append([rank, name, times, point_totals, id])
        
        self.db.end_sql_connection(connection)
        return rankings
