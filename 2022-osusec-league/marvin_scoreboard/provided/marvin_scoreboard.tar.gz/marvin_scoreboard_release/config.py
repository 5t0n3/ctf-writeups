DB_CONFIG = {
    "host": "localhost",
    "user": "REDACTED",
    "password": "REDACTED",
    "database": "REDACTED",
    "auth_plugin": "REDACTED",
}

GRAPH_PLAYERS = 100
GRAPH_HISTORY = 20

TIME_OFFSET_FROM_UTC = -7
