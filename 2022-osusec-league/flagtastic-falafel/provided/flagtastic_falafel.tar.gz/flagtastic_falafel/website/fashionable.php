<h3>Fashionable Falafel</h3>
<img src="images/fashionable.png">
<p>This guy just walked right into the kitchen and onto the plate! Where did he get his dapper looks? No one knows, because he doesn't have a mouth and can't tell us.</p>
<hr>