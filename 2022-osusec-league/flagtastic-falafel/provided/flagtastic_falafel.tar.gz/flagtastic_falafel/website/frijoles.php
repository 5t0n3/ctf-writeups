<h3>Fijoles Falafel</h3>
<img src="images/fijoles.png">
<p>These Frijoles Falafels are formed from a fantastic fruit that is sure to give you flatulence!</p>
<hr>