<h3>Fuzzy Falafel</h3>
<img src="images/fuzzy.png">
<p>Was it left out of the fridge too long or will it be your next furry friend? You decide.</p>
<hr>