<h3>Fast Falafel</h3>
<img src="images/fast.png">
<p>This Falafel has been subjected to a high speed ride on the hood of a car, so it might be a little squished.</p>
<hr>