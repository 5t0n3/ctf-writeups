<h3>Flaming Falafel</h3>
<img src="images/flaming.png">
<p>The best way to get a nice crispy falafel is definitely fire! Ghost peppers have nothing on these!!</p>
<hr>