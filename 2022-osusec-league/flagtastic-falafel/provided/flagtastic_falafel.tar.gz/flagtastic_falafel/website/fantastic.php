<h3>Fantastic Falafel</h3>
<img src="images/fantastic.png">
<p>This chocolatey falafel gets its name from its Fantastic flavor. Also that weird green blob on top is actually pretty good too, although we still haven't figured out what it is.</p>
<hr>