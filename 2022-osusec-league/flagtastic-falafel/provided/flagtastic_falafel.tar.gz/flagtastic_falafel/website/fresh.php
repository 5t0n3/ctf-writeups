<h3>Fresh Falafel</h3>
<img src="images/fresh.png">
<p>The freshest falafel in our kitchen, this one has only been left out of our fridge for fourteen days!</p>
<hr>