<h3>Fibrous Falafel</h3>
<img src="images/fibrous.png">
<p>Pickled ramen and giant falafel, what better combination could there possibly be?! This Fibrous Falafel is top tier.</p>
<hr>