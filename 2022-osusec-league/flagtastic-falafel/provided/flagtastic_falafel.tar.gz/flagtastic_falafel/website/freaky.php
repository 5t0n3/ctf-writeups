<h3>Freaky Falafel</h3>
<img src="images/freaky.png">
<p>This mutant blue Freaky Falafel monster thing has been wreaking havoc in our kitchen!! Thank you so much for finally taking it off our hands!</p>
<hr>