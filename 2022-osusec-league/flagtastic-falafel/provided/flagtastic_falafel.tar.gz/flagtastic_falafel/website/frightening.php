<h3>Frightening Falafel</h3>
<img src="images/frightening.png">
<p>It doesn't take a big brain to know to stay away from this frightening four-footed falafel!</p>
<hr>