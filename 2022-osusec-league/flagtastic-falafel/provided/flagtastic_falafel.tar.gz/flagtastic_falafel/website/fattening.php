<h3>Fattening Falafel</h3>
<img src="images/fattening.png">
<p>For centuries, people have been scratching their heads trying to figure out what the hole in the middle of donuts is for. Well, we figured it out!! It almost perfectly fits a nice crunchy ball of Falafel. Enjoy!</p>
<hr>