<h3>Famous Falafel</h3>
<img src="images/famous.png">
<p>We haven't met anyone yet who doesn't love our Famous Falafel! Not even this cat... Watch out for cat hairs in your food...</p>
<hr>