<h3>Fake Falafel</h3>
<img src="images/fake.png">
<p>This fake falafel is actually ice cream!! How sneaky.</p>
<hr>