<h3>Fabled Falafel</h3>
<img src="images/fabled.png">
<p>An oreo showed up in our flagtastic kitchen one day, and this fabled falafel followed forthwith.</p>
<hr>