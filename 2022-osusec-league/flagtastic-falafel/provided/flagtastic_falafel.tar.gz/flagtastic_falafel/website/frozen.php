<h3>Frozen Falafel</h3>
<img src="images/frozen.png">
<p>We found these in a glacier!! We're pretty sure they're falafel! Might have a little freezer burn</p>
<hr>