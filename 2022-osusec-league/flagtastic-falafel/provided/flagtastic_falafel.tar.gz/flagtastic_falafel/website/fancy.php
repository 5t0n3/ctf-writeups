<h3>Fancy Falafel</h3>
<img src="images/fancy.png">
<p>This Fancy Falafel is gold plated!! Crazy, right? Yes, definitely crazy. Why did you buy this?!!</p>
<hr>