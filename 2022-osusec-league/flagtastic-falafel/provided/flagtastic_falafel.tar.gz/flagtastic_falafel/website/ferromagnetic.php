<h3>Ferromagnetic Falafel</h3>
<img src="images/ferromagnetic.png">
<p>Pretty much just what it sounds like. Falafel, but it's Ferromagnetic! We aren't sure what it tastes like, but it sure looks cool!</p>
<hr>