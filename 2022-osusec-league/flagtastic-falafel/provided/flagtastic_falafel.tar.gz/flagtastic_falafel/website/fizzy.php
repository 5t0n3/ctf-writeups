<h3>Fizzy Falafel</h3>
<img src="images/fizzy.png">
<p>We got tired of those gross tapioca ball things in our bubble tea and decided to add a little more protein. Best eaten with a spoon (or a reallly thick straw)!</p>
<hr>