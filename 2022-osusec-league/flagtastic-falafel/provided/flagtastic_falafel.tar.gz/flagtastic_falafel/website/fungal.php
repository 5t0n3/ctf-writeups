<h3>Fungal Falafel</h3>
<img src="images/fungal.png">
<p>This fungal falafel is sort of like a mario mushroom - if you eat it you will probably grow really big, because you'll like it so much you won't stop eating!!</p>
<hr>