<h3>Fruit Falafel</h3>
<img src="images/fruit.png">
<p>This fruit falafel was made with a box of green gelatin and some strawberries we found in the back corner of our refrigerator... Also some falafel (of course)</p>
<hr>