<h3>Futuristic Falafel</h3>
<img src="images/futuristic.png">
<p>Hopefully this UFF (Unidentified Flying Falafel) finds a landing spot in your mouth!</p>
<hr>