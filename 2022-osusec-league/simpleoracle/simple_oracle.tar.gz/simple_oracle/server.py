#!/usr/bin/env python3
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
from os import urandom
from base64 import b64decode, b64encode

# import the flag
from flag import FLAG

# block size of the cipher
BLOCK_SIZE = 128


def gen_key(keysize:int):
    # return random key (keysize given in bits, urandom parameter is # bytes)
    return urandom(keysize//8)


def add_padding(ptxt:bytes) -> bytes:
    # creating padding object
    padder = padding.PKCS7(BLOCK_SIZE).padder()
    
    # return the padded ptxt
    return padder.update(ptxt) + padder.finalize()

 
def encrypt(key:bytes, ptxt:str) -> str:
    # generate random IV
    iv = urandom(BLOCK_SIZE//8)
    # iv = load_key('iv.bin')
    
    # create encryptor object
    encryptor = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend()).encryptor()

    # apply padding to the ptxt
    padded_ptxt = add_padding(ptxt.encode())
    
    # encrypt the padded plaintext. 
    # IV is concatenated to the beginning of ciphertext so that it can be recovered for decrypting
    encrypted_data = iv + encryptor.update(padded_ptxt) + encryptor.finalize()

    # convert bytes to base64 and return as string
    return b64encode(encrypted_data).decode()


def decrypt(key:bytes, ctxt:str) -> str: 
    # split IV from rest of ciphertext
    iv, ctxt = b64decode(ctxt.encode())[:16], b64decode(ctxt.encode())[16:] 

    # create the unpadder and decryptor objects
    unpadder = padding.PKCS7(BLOCK_SIZE).unpadder()
    decryptor = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend()).decryptor()

    # decrypt the ciphertext
    decrypted_data = decryptor.update(ctxt) + decryptor.finalize()

    # remove the padding
    ptxt = unpadder.update(decrypted_data) + unpadder.finalize()

    # return the ptxt
    return ptxt


def check_decryption(k:bytes, c:str) -> str:
    try:
        ptxt = decrypt(k, c)
        return 'SUCCESS'
    except:
        return "FAILED"


if __name__ == '__main__':
    # load in the saved key
    # key = load_key('key.bin')
    key = gen_key(BLOCK_SIZE)

    # encrypt the flag using the key
    enc_flag = encrypt(key, FLAG)

    # print the encrypted flag
    print(f'The encrypted flag is: {enc_flag}')

    # loop infinitely
    while True:
        # receive ciphertext from user
        ctxt = str(input())

        # get the result of decryption
        result = check_decryption(key, ctxt)

        # print result
        print(result)

        
