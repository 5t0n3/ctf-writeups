#!/usr/bin/env python3
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from base64 import b64decode, b64encode
from server import encrypt, check_decryption, decrypt
from os import urandom

# block size of the cipher in bits
BLOCK_SIZE = 128
BLOCK_BYTES = 16

# place holder flag
FLAG = 'NOT_FLAG'

# change color of text
GREEN = lambda s: '\033[32m' + str(s) + '\033[0m'
RED = lambda s: '\033[31m' + str(s) + '\033[0m'



# apply PKCS7 padding to the flag 
padder = padding.PKCS7(BLOCK_SIZE).padder()
padded_flag = padder.update(FLAG.encode()) + padder.finalize()


# print out padding scheme info
print('Padding scheme used in this challenge is PKCS7.')
print('This padding scheme sets the value of all padding bytes to the number of padding bytes needed')
print()
print(f'{BLOCK_SIZE//8} bytes (block size) - {RED(len(FLAG))} bytes = {GREEN(len(padded_flag) - len(FLAG))} bytes')
# thanks chatgpt for formating
padding_hex = '\\x' + '\\x'.join(format(x, '02x') for x in padded_flag[len(FLAG):])
print(f'Padded flag: {RED(FLAG)}{GREEN(padding_hex)}')
print()
input()
print()

# generate new key
KEY = urandom(BLOCK_BYTES)

# now we encrypt the flag
enc_flag = encrypt(KEY, FLAG)
enc_flag_bin = b64decode(enc_flag.encode())
enc_flag_str = '\\x' + '\\x'.join(format(x, '02x') for x in enc_flag_bin)

# separate IV from the first block
iv, c1 = enc_flag_str[:4*(BLOCK_BYTES)], enc_flag_str[4*(BLOCK_BYTES):]

# these are the actual bytes
IV, C1 = enc_flag_bin[:BLOCK_BYTES], enc_flag_bin[BLOCK_BYTES:]


# print out both blocks
print('Encrypted flag: ')
print('IV: ')
print(iv)
print('C1: ')
print(c1)
print()
input()


# Mike Rosulek has a really helpful webpage for understanding this attack
# https://web.engr.oregonstate.edu/~rosulekm/crypto/padding.html


# To perform this attack we will alter the ciphertext one byte 
# at a time to eventually recover the entire plaintext

# you can communicate with the 'padding oracle' server. 
# The server will decrypt the ciphertext it is sent and report 
# whether the decryption was successful or not


# first we edit the last byte of the of the IV so that we can
# find out what the last byte of the padded plaintext is


# here is function to change the byte at a specific location of a bytes object
def change_byte(ctxt:bytes, new_value:int, idx:int) -> bytes:
    # convert to bytearray so that it is mutible
    b_arr = bytearray(ctxt)

    # replace the byte at the index with the supplied value
    b_arr[idx] = new_value

    # return as bytes
    return bytes(b_arr)


# to derive the first byte of the plaintext, we loop through
# all possible values for that byte
for i in range(0x0, 0xff):
    # skip the case where the values is the same as the encrypted flag
    if i == int(enc_flag_bin[BLOCK_BYTES - 1]):
        continue
    
    # create new ciphertext with modified byte
    chosen_ctxt = change_byte(enc_flag_bin, i, BLOCK_BYTES - 1)

    # check if the new ciphertext will decrypt
    if check_decryption(KEY, b64encode(chosen_ctxt).decode()) == 'SUCCESS':
        oracle_byte = i
        break

# original byte in the IV
original_byte = enc_flag_bin[BLOCK_BYTES - 1]

print()
print(f'Last byte in IV: {hex(original_byte)}')
print(f'Byte learned using oracle: {hex(oracle_byte)}')
print()

# byte that comes directly from the AES block cipher
# see below for explaination on finding it
aes_byte = oracle_byte ^ 0x1

print(f'So {hex(oracle_byte)} ⊕ 0x?? = 0x01 ---> {hex(oracle_byte)} ⊕ 0x01 = {hex(aes_byte)}')
print()
print(f'Now to find the last byte of the plaintext we just need to XOR the original byte with this new value:')

# we can get the recovered plaintext byte by performing XOR with the byte that was discovered
recovered_byte = int(original_byte) ^ aes_byte
print(f'{hex(original_byte)} ⊕ {hex(aes_byte)} = {hex(recovered_byte)}')
input()
print()

# # Now to get the rest of the blocks of the ciphertext we just need to 
# # edit the ciphertext so that it will decrypt to 0x2 in the last two bytes
# # We need to find the byte that in the second position causes the decryption to have
# # a value of 0x02. Note the last byte also needs to have a value of 0x02.

# starting byte string that can be XORed with the ciphertext to get the plaintext
aes_bytes = aes_byte.to_bytes(1, 'little')
aes_bytes_str = '\\x' + '\\x'.join(format(x, '02x') for x in aes_bytes)
print(f'Learned AES bytes so far: {aes_bytes_str}')

# byte that results in 0x02 in decrypted block
# calculation is explained below
two_byte = aes_byte ^ 0x2

print(f'We know that {hex(oracle_byte)} ⊕ {hex(aes_byte)} = 0x01. So we find {hex(aes_byte)} ⊕ {hex(0x2)} = {hex(two_byte)}')
print(f'So we set the last byte of our chosen ciphertext to {hex(two_byte)} to ensure that the last byte will be 0x2')


chosen_ctxt = change_byte(enc_flag_bin, two_byte, BLOCK_BYTES - 1)
chosen_ctxt_iv_str = '\\x' + '\\x'.join(format(x, '02x') for x in chosen_ctxt[:BLOCK_BYTES])
print('Chosen ctxt IV: ')
print(chosen_ctxt_iv_str)
print()
input()


print(f'You can see this happening by looking at the decrypted ciphertext: ')
decryptor = Cipher(algorithms.AES(KEY), modes.CBC(chosen_ctxt[:16]), backend=default_backend()).decryptor()
# decrypt the ciphertext
decrypted_data = decryptor.update(chosen_ctxt[16:]) + decryptor.finalize()
print(f'{decrypted_data = }')
print()

original_byte = enc_flag_bin[BLOCK_BYTES - 2]
# Now we loop through all the possibilites of the second to last byte to find the second aes block
for i in range(0x0, 0xff):
    # skip the case where the values are the same
    if i == int(original_byte):
        continue
    
    # create new ciphertext with modified byte
    chosen_ctxt = change_byte(chosen_ctxt, i, BLOCK_BYTES - 2)

    # check if the new ciphertext will decrypt
    if check_decryption(KEY, b64encode(chosen_ctxt).decode()) == 'SUCCESS':
        aes_byte = i ^ 0x2
        break

print(f'Found second AES byte: {hex(aes_byte)}')
recovered_byte = aes_byte ^ original_byte
print(f'To find the second recovered byte we repeat the same calculation')
print(f'{hex(aes_byte)} ⊕ {hex(original_byte)} = {hex(recovered_byte)}')






